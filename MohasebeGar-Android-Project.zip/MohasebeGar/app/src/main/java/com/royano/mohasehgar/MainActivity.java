package com.royano.mohasehgar;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    EditText first, second; TextView result;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,36,28,24); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(0xFFF4F7F4);
        TextView title = new TextView(this); title.setText("محاسبه‌گر فارسی"); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD); title.setTextColor(0xFF176B45); title.setGravity(Gravity.CENTER); root.addView(title, match(WRAP_CONTENT));
        TextView subtitle = new TextView(this); subtitle.setText("دو عدد را وارد کنید و عملیات موردنظر را انتخاب کنید"); subtitle.setTextSize(14); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,12,0,24); root.addView(subtitle, match(WRAP_CONTENT));
        first = field("عدد اول"); root.addView(first, match(WRAP_CONTENT)); second = field("عدد دوم"); LinearLayout.LayoutParams p=match(WRAP_CONTENT); p.topMargin=12; root.addView(second,p);
        String[][] ops={{"جمع +","+"},{"تفریق −","-"},{"ضرب ×","*"},{"تقسیم ÷","/"},{"درصد ٪","%"}};
        for(int i=0;i<ops.length;i+=2){ LinearLayout row=new LinearLayout(this); row.setOrientation(0); for(int j=i;j<Math.min(i+2,ops.length);j++){ final String op=ops[j][1]; Button btn=new Button(this); btn.setText(ops[j][0]); btn.setOnClickListener(v->calculate(op)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,WRAP_CONTENT,1); bp.setMargins(4,12,4,0); row.addView(btn,bp);} root.addView(row,match(WRAP_CONTENT)); }
        result=new TextView(this); result.setText("نتیجه: —"); result.setTextSize(23); result.setTypeface(null,Typeface.BOLD); result.setTextColor(0xFF176B45); result.setGravity(Gravity.CENTER); result.setPadding(0,30,0,20); root.addView(result,match(WRAP_CONTENT));
        Button clear=new Button(this); clear.setText("پاک کردن"); clear.setOnClickListener(v->{first.setText("");second.setText("");result.setText("نتیجه: —");}); root.addView(clear,match(WRAP_CONTENT));
        setContentView(root);
    }
    static final int WRAP_CONTENT=-2;
    LinearLayout.LayoutParams match(int h){return new LinearLayout.LayoutParams(-1,h);}
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(18);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);e.setGravity(Gravity.CENTER);return e;}
    void calculate(String op){try{double a=Double.parseDouble(first.getText().toString().replace('٫','.'));double b=second.getText().length()==0?0:Double.parseDouble(second.getText().toString().replace('٫','.'));double r;switch(op){case "+":r=a+b;break;case "-":r=a-b;break;case "*":r=a*b;break;case "/":if(b==0){result.setText("تقسیم بر صفر ممکن نیست");return;}r=a/b;break;default:r=a*b/100.0;} if(Double.isNaN(r)||Double.isInfinite(r)){result.setText("عدد نامعتبر");return;}String s=new DecimalFormat("#,##0.########").format(r); result.setText("نتیجه: "+s);}catch(Exception e){result.setText("لطفاً عدد معتبر وارد کنید");}}
}
